export interface CourseParams {
  q: string,
  options: object,
  hideCompleted: boolean,
  status: string,
}
