<template>
  <VRating clearable />
</template>
