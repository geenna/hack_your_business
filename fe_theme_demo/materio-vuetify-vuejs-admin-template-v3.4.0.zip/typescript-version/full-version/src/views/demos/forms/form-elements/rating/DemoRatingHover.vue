<template>
  <VRating hover />
</template>
