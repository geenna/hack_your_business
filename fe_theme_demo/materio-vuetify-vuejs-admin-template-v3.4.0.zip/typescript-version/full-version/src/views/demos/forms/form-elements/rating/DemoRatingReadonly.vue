<template>
  <VRating
    readonly
    :model-value="4"
  />
</template>
