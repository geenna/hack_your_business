export default [
  {
    title: 'Tables',
    icon: { icon: 'ri-table-line' },
    children: [
      { title: 'Simple Table', icon: { icon: 'ri-layout-grid-line' }, to: 'tables-simple-table' },
      { title: 'Data Table', icon: { icon: 'ri-grid-line' }, to: 'tables-data-table' },
    ],
  },
]
