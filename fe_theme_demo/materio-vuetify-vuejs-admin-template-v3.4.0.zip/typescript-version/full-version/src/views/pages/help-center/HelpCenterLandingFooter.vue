<template>
  <div
    class="text-center"
    style="padding-block: 6.25rem;"
  >
    <h4 class="text-h4 text-center mb-4">
      Still need help?
    </h4>
    <p class="text-body-1">
      Our specialists are always happy to help.
      <br>
      Contact us during standard business hours or email us 24/7 and we'll get back to you.
    </p>
    <div class="d-flex justify-center gap-4 flex-wrap">
      <VBtn>Visit our community</VBtn>
      <VBtn>Contact us</VBtn>
    </div>
  </div>
</template>
