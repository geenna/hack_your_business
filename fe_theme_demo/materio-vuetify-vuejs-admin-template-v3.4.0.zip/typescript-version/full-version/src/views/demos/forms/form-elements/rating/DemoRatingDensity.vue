<template>
  <VRating density="compact" />
</template>
