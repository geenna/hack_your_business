<template>
  <VTextField
    label="Regular"
    placeholder="Placeholder Text"
  />
</template>
